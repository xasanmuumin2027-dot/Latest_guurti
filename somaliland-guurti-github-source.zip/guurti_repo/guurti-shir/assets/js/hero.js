/* Loads the Three.js hero only where it adds value and costs little. */
(function () {
  var hero = document.querySelector('.guurti-hero');
  var canvas = hero && hero.querySelector('canvas');
  if (!canvas || !window.GuurtiHero) return;

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var small = window.matchMedia('(max-width: 900px)').matches;
  var conn = navigator.connection || {};
  var lowPower = conn.saveData || /(^|-)2g$/.test(conn.effectiveType || '') ||
    (navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4) ||
    (navigator.deviceMemory && navigator.deviceMemory < 4);
  var coarse = window.matchMedia('(pointer: coarse)').matches && small;

  // Phones, tablets in portrait, data-saver and low-power devices keep the lightweight CSS ring.
  if (small || coarse || lowPower) return;

  var gl;
  try { gl = canvas.getContext('webgl2') || canvas.getContext('webgl'); } catch (e) {}
  if (!gl) return;

  var start = function () {
    import(window.GuurtiHero.module).then(function (m) {
      m.default(canvas, { reduced: reduced });
      hero.classList.add('guurti-hero--3d');
    }).catch(function () { /* keep fallback */ });
  };
  if ('requestIdleCallback' in window) requestIdleCallback(start, { timeout: 1500 });
  else setTimeout(start, 300);
})();

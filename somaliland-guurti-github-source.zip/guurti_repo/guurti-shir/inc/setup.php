<?php
/**
 * First-activation setup + optional labelled placeholder content.
 *
 * @package guurti-shir
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Create starter pages once and flush permalinks. Never overwrites an existing front page setup.
 */
function guurti_shir_activate() {
	if ( get_option( 'guurti_shir_setup_done' ) ) {
		flush_rewrite_rules();
		return;
	}
	$make = function ( $title, $slug, $content = '' ) {
		$existing = get_page_by_path( $slug );
		if ( $existing ) {
			return $existing->ID;
		}
		return wp_insert_post(
			array(
				'post_title'   => $title,
				'post_name'    => $slug,
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_content' => $content,
			)
		);
	};
	$about_txt = '<!-- wp:paragraph --><p class="guurti-note">[Placeholder – About the Guurti text awaiting official approval. Edit this page in WordPress Admin.]</p><!-- /wp:paragraph -->';
	$contact   = '<!-- wp:paragraph --><p class="guurti-note">[Placeholder – official address, phone and email awaiting approval. Edit in the footer template part or on this page.]</p><!-- /wp:paragraph --><!-- wp:shortcode -->[guurti_contact_form]<!-- /wp:shortcode -->';

	$home  = $make( 'Home', 'home' );
	$make( 'About the Guurti', 'about-the-guurti', $about_txt );
	$news  = $make( 'News & Media', 'news' );
	$make( 'Contact Us', 'contact-us', $contact );

	if ( 'posts' === get_option( 'show_on_front' ) && ! get_option( 'page_on_front' ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home );
		update_option( 'page_for_posts', $news );
	}
	if ( 'Just another WordPress site' === get_option( 'blogdescription' ) ) {
		update_option( 'blogdescription', 'House of Elders – Golaha Guurtida' );
	}
	update_option( 'guurti_shir_setup_done', 1 );
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'guurti_shir_activate' );

/* -------- Optional placeholder content (Appearance > Shir setup) -------- */

function guurti_shir_admin_menu() {
	add_theme_page( 'Shir setup', 'Shir setup', 'manage_options', 'guurti-shir-setup', 'guurti_shir_setup_page' );
}
add_action( 'admin_menu', 'guurti_shir_admin_menu' );

function guurti_shir_placeholder_items() {
	$p = '[PLACEHOLDER] ';
	return array(
		'guurti_leader'    => array( array( $p . 'Speaker – name awaiting approval', 'Position awaiting approval', 'Booqasho sugaysa ansixin' ), array( $p . 'First Deputy – name awaiting approval', 'Position awaiting approval', 'Booqasho sugaysa ansixin' ), array( $p . 'Second Deputy – name awaiting approval', 'Position awaiting approval', 'Booqasho sugaysa ansixin' ) ),
		'guurti_member'    => array( array( $p . 'Member 1 – name awaiting approval', 'Member', 'Xubin' ), array( $p . 'Member 2 – name awaiting approval', 'Member', 'Xubin' ), array( $p . 'Member 3 – name awaiting approval', 'Member', 'Xubin' ), array( $p . 'Member 4 – name awaiting approval', 'Member', 'Xubin' ) ),
		'guurti_committee' => array( array( $p . 'Committee 1 – name awaiting approval' ), array( $p . 'Committee 2 – name awaiting approval' ), array( $p . 'Committee 3 – name awaiting approval' ) ),
		'guurti_session'   => array( array( $p . 'Session – title and date awaiting approval' ), array( $p . 'Session – title and date awaiting approval' ) ),
		'guurti_bill'      => array( array( $p . 'Legislation item – awaiting approval' ), array( $p . 'Resolution – awaiting approval' ) ),
		'guurti_document'  => array( array( $p . 'Publication – awaiting approval' ), array( $p . 'Publication – awaiting approval' ) ),
		'guurti_gallery'   => array( array( $p . 'Gallery item – image awaiting approval' ), array( $p . 'Gallery item – image awaiting approval' ), array( $p . 'Gallery item – image awaiting approval' ) ),
		'post'             => array( array( $p . 'News item – awaiting approval' ), array( $p . 'News item – awaiting approval' ), array( $p . 'News item – awaiting approval' ) ),
	);
}

function guurti_shir_setup_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$msg = '';
	if ( isset( $_POST['guurti_action'] ) && check_admin_referer( 'guurti_setup' ) ) {
		if ( 'add' === $_POST['guurti_action'] ) {
			foreach ( guurti_shir_placeholder_items() as $pt => $items ) {
				foreach ( $items as $i => $it ) {
					$id = wp_insert_post(
						array(
							'post_type'    => $pt,
							'post_status'  => 'publish',
							'post_title'   => $it[0],
							'post_content' => '<!-- wp:paragraph --><p>[Placeholder content awaiting official approval.]</p><!-- /wp:paragraph -->',
							'post_excerpt' => '[Placeholder summary awaiting official approval.]',
							'menu_order'   => $i,
						)
					);
					if ( $id && ! is_wp_error( $id ) ) {
						update_post_meta( $id, 'guurti_placeholder', '1' );
						update_post_meta( $id, 'guurti_title_so', '[Meel-qabsade – sugaya ansixin rasmi ah]' );
						update_post_meta( $id, 'guurti_excerpt_so', '[Meel-qabsade – sugaya ansixin rasmi ah.]' );
						if ( isset( $it[1] ) ) {
							update_post_meta( $id, 'guurti_role', $it[1] );
							update_post_meta( $id, 'guurti_role_so', $it[2] );
						}
					}
				}
			}
			$msg = 'Labelled placeholder content added.';
		} elseif ( 'remove' === $_POST['guurti_action'] ) {
			$ids = get_posts( array( 'post_type' => 'any', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => 'guurti_placeholder', 'meta_value' => '1' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			foreach ( $ids as $id ) {
				wp_delete_post( $id, true );
			}
			$msg = count( $ids ) . ' placeholder items removed.';
		}
	}
	?>
	<div class="wrap">
		<h1>Shir setup</h1>
		<?php if ( $msg ) : ?>
			<div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div>
		<?php endif; ?>
		<p>Add clearly labelled <strong>[PLACEHOLDER]</strong> entries so you can review the design before real, officially approved content is entered. Remove them with one click when ready. No real names, statistics or contact details are ever created.</p>
		<form method="post">
			<?php wp_nonce_field( 'guurti_setup' ); ?>
			<button class="button button-primary" name="guurti_action" value="add">Add placeholder content</button>
			<button class="button" name="guurti_action" value="remove" onclick="return confirm('Delete all placeholder items?');">Remove all placeholder content</button>
		</form>
		<h2>Where to edit things</h2>
		<ul style="list-style:disc;margin-left:1.2em">
			<li><strong>Homepage sections, buttons, header, footer, top bar:</strong> Appearance → Editor → Templates / Patterns (Home page = “Front Page” template; header, top bar and footer are Template Parts).</li>
			<li><strong>Menus:</strong> Appearance → Editor → Template Parts → Header → click the menu.</li>
			<li><strong>Members, leadership, committees, sessions, legislation, publications, gallery:</strong> left admin menu.</li>
			<li><strong>News:</strong> Posts. Each entry has a Somali translation box.</li>
			<li><strong>Contact form recipient:</strong> Settings → General → Administration Email Address.</li>
		</ul>
	</div>
	<?php
}

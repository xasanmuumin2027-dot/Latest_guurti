<?php
/**
 * Meta boxes (work in the block editor and the classic editor).
 *
 * @package guurti-shir
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function guurti_shir_add_meta_boxes() {
	$all = guurti_shir_fields();
	foreach ( array_merge( array_keys( $all ), array( 'post' ) ) as $pt ) {
		if ( isset( $all[ $pt ] ) ) {
			add_meta_box( 'guurti_details', __( 'Details', 'guurti-shir' ), 'guurti_shir_render_box', $pt, 'normal', 'high', array( 'fields' => $all[ $pt ] ) );
		}
		add_meta_box( 'guurti_somali', __( 'Somali translation (Af-Soomaali)', 'guurti-shir' ), 'guurti_shir_render_box', $pt, 'normal', 'default', array( 'fields' => guurti_shir_translation_fields() ) );
	}
}
add_action( 'add_meta_boxes', 'guurti_shir_add_meta_boxes' );

function guurti_shir_render_box( $post, $box ) {
	wp_nonce_field( 'guurti_save_' . $post->ID, 'guurti_nonce' );
	echo '<table class="form-table" role="presentation">';
	foreach ( $box['args']['fields'] as $key => $f ) {
		$val = get_post_meta( $post->ID, $key, true );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $f[0] ) . '</label></th><td>';
		if ( 'textarea' === $f[1] ) {
			echo '<textarea class="large-text" rows="3" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $val ) . '</textarea>';
		} else {
			$input = in_array( $f[1], array( 'date' ), true ) ? 'date' : ( 'email' === $f[1] ? 'email' : ( in_array( $f[1], array( 'url', 'file' ), true ) ? 'url' : 'text' ) );
			echo '<input class="regular-text" style="width:100%;max-width:520px" type="' . esc_attr( $input ) . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '">';
			if ( 'file' === $f[1] ) {
				echo ' <button type="button" class="button guurti-pick" data-target="' . esc_attr( $key ) . '">' . esc_html__( 'Choose from Media Library', 'guurti-shir' ) . '</button>';
			}
		}
		echo '</td></tr>';
	}
	echo '</table>';
}

function guurti_shir_save_meta( $post_id, $post ) {
	if ( ! isset( $_POST['guurti_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['guurti_nonce'] ) ), 'guurti_save_' . $post_id ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$all    = guurti_shir_fields();
	$fields = array_merge( isset( $all[ $post->post_type ] ) ? $all[ $post->post_type ] : array(), guurti_shir_translation_fields() );
	foreach ( $fields as $key => $f ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below.
		update_post_meta( $post_id, $key, guurti_shir_sanitize( is_string( $raw ) ? $raw : '', $f[1] ) );
	}
}
add_action( 'save_post', 'guurti_shir_save_meta', 10, 2 );

function guurti_shir_admin_assets( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script( 'guurti-admin', get_template_directory_uri() . '/assets/js/admin.js', array( 'jquery' ), GUURTI_SHIR_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'guurti_shir_admin_assets' );

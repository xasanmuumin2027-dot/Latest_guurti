<?php
/**
 * Custom post types and shared "Somali translation" meta.
 *
 * @package guurti-shir
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Definitions: slug => [label singular, plural, rewrite slug, icon, Somali label].
 *
 * @return array
 */
function guurti_shir_types() {
	return array(
		'guurti_leader'    => array( 'Leader', 'Leadership', 'leadership', 'dashicons-businessperson' ),
		'guurti_member'    => array( 'Member', 'Members', 'members', 'dashicons-groups' ),
		'guurti_committee' => array( 'Committee', 'Committees', 'committees', 'dashicons-networking' ),
		'guurti_session'   => array( 'Session', 'Sessions', 'sessions', 'dashicons-calendar-alt' ),
		'guurti_bill'      => array( 'Legislation item', 'Legislation & Resolutions', 'legislation', 'dashicons-media-text' ),
		'guurti_document'  => array( 'Document', 'Publications & Archives', 'publications', 'dashicons-media-document' ),
		'guurti_gallery'   => array( 'Gallery item', 'Gallery & Videos', 'gallery', 'dashicons-format-gallery' ),
	);
}

function guurti_shir_register_types() {
	$pos = 21;
	foreach ( guurti_shir_types() as $slug => $d ) {
		register_post_type(
			$slug,
			array(
				'labels'          => array(
					'name'          => $d[1],
					'singular_name' => $d[0],
					'add_new_item'  => 'Add new ' . strtolower( $d[0] ),
					'edit_item'     => 'Edit ' . strtolower( $d[0] ),
					'all_items'     => 'All ' . strtolower( $d[1] ),
				),
				'public'          => true,
				'show_in_rest'    => true,
				'has_archive'     => $d[2],
				'rewrite'         => array( 'slug' => $d[2] ),
				'menu_icon'       => $d[3],
				'menu_position'   => $pos++,
				'supports'        => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'revisions', 'custom-fields' ),
				'capability_type' => 'post',
			)
		);
	}
}
add_action( 'init', 'guurti_shir_register_types' );

/**
 * Field map used by meta registration and the meta boxes.
 * type: text | url | date | file
 *
 * @return array
 */
function guurti_shir_fields() {
	return array(
		'guurti_leader'    => array(
			'guurti_role'    => array( 'Position (English)', 'text' ),
			'guurti_role_so' => array( 'Position (Somali)', 'text' ),
			'guurti_email'   => array( 'Official email', 'email' ),
		),
		'guurti_member'    => array(
			'guurti_role'    => array( 'Title (English)', 'text' ),
			'guurti_role_so' => array( 'Title (Somali)', 'text' ),
			'guurti_region'  => array( 'Region / constituency', 'text' ),
			'guurti_email'   => array( 'Official email', 'email' ),
		),
		'guurti_committee' => array(
			'guurti_chair' => array( 'Chairperson', 'text' ),
		),
		'guurti_session'   => array(
			'guurti_date'   => array( 'Date', 'date' ),
			'guurti_time'   => array( 'Time (e.g. 09:00)', 'text' ),
			'guurti_venue'  => array( 'Venue', 'text' ),
			'guurti_status' => array( 'Status (e.g. Scheduled)', 'text' ),
		),
		'guurti_bill'      => array(
			'guurti_kind' => array( 'Type (Bill / Resolution / Act)', 'text' ),
			'guurti_ref'  => array( 'Reference number', 'text' ),
			'guurti_date' => array( 'Date', 'date' ),
			'guurti_file' => array( 'Document file (PDF)', 'file' ),
		),
		'guurti_document'  => array(
			'guurti_kind' => array( 'Category (e.g. Report)', 'text' ),
			'guurti_year' => array( 'Year', 'text' ),
			'guurti_file' => array( 'Document file (PDF)', 'file' ),
		),
		'guurti_gallery'   => array(
			'guurti_video' => array( 'Video URL (YouTube / Vimeo / file) – optional', 'url' ),
		),
	);
}

/**
 * Translation fields shared by every content type incl. News posts.
 *
 * @return array
 */
function guurti_shir_translation_fields() {
	return array(
		'guurti_title_so'   => array( 'Title (Somali)', 'text' ),
		'guurti_excerpt_so' => array( 'Summary (Somali)', 'textarea' ),
	);
}

function guurti_shir_sanitize( $value, $type = 'text' ) {
	switch ( $type ) {
		case 'url':
		case 'file':
			return esc_url_raw( $value );
		case 'email':
			return sanitize_email( $value );
		case 'textarea':
			return sanitize_textarea_field( $value );
		default:
			return sanitize_text_field( $value );
	}
}

function guurti_shir_register_meta() {
	$all = guurti_shir_fields();
	$tr  = guurti_shir_translation_fields();
	$types = array_merge( array_keys( $all ), array( 'post' ) );

	foreach ( $types as $pt ) {
		$fields = array_merge( isset( $all[ $pt ] ) ? $all[ $pt ] : array(), $tr );
		foreach ( $fields as $key => $f ) {
			$type = $f[1];
			register_post_meta(
				$pt,
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'default'           => '',
					'sanitize_callback' => function ( $v ) use ( $type ) {
						return guurti_shir_sanitize( $v, $type );
					},
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}
	register_post_meta( '', 'guurti_placeholder', array( 'type' => 'string', 'single' => true, 'show_in_rest' => false ) );
}
add_action( 'init', 'guurti_shir_register_meta' );

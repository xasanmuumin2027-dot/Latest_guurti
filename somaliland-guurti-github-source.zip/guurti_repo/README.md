# Somaliland House of Elders — Guurti Shir

This repository contains the `Guurti Shir` WordPress block theme (version 1.2.0).

## Install as a WordPress theme

1. In WordPress Admin, open **Appearance → Themes → Add New Theme → Upload Theme**.
2. Upload the original `guurti-shir-1.2.0.zip` theme package, or create a ZIP of the `guurti-shir/` folder in this repository.
3. Install and activate the theme.

## Hosting note

This is a PHP-based WordPress theme. GitHub stores the source code but does not run WordPress/PHP. Cloudflare Pages also does not execute PHP or provide a WordPress database, so deploying this theme ZIP directly to GitHub Pages or Cloudflare Pages will not produce a working WordPress site. Use a WordPress-compatible PHP host to run it. A static conversion would be a separate project and would not retain WordPress admin features, custom post types, or forms as-is.

## Requirements declared by the theme

- WordPress 6.6 or later
- PHP 7.4 or later
